
TITLE: 
Photogenic - Responsive Bootstrap 4 Template for Photographers

AUTHOR:
Design by FreeHTML5.co
Website: http://freehtml5.co/



CREDITS:

Bootstrap
http://getbootstrap.com/

jQuery
http://jquery.com/

Google Fonts
https://fonts.google.com

Owl Carousel
https://owlcarousel2.github.io/OwlCarousel2/

Font Awesome
https://fontawesome.com

Isotope
https://isotope.metafizzy.co

Demo Images:
http://unsplash.com

